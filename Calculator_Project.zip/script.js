function showMessage() {
    alert("Hello! This is your hosted website.");
}